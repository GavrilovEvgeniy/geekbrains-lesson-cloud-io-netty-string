public class Orange extends Fruit {

    Orange() {
        this.weight = 1.5f;
        this.type = "Orange";
    }
}
