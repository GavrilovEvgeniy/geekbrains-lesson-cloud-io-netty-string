public class Apple extends Fruit {

    Apple() {
        this.weight = 1.0f;
        this.type = "Apple";
    }
}
