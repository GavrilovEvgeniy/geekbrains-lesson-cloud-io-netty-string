public class Fruit {

    protected float weight;
    protected String type;

}

